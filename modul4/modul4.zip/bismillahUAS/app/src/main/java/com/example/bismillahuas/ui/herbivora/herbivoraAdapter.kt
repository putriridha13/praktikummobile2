package com.example.bismillahuas.ui.herbivora

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.example.bismillahuas.R
import com.example.bismillahuas.animals
import com.example.bismillahuas.animalsDetail
import com.example.bismillahuas.animalsViewModel

class herbivoraAdapter (
    private val context: Context,
    private val dataset: List<animals>
    ): RecyclerView.Adapter<herbivoraAdapter.herbivoraViewHolder> () {

    private val viewModel = animalsViewModel()
    class herbivoraViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val herbivoraImg: ImageView = view.findViewById(R.id.hewan_img)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): herbivoraViewHolder {
        val layout = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.fragment_animals, parent, false)
        return  herbivoraViewHolder(layout)
    }

    override fun getItemCount() = dataset.size

    override fun onBindViewHolder(
        holder: herbivoraViewHolder,
        position: Int,
    ) {
        val herbivoraData = dataset[position]
        holder.herbivoraImg.setImageResource(herbivoraData.imageResourceId)

        holder.itemView.setOnClickListener {
            viewModel.setAnimals(herbivoraData, context)

            val intent = Intent(context, animalsDetail::class.java). apply {
                putExtra("name", viewModel.name.value)
                putExtra("description", viewModel.desc.value)
                putExtra("image", viewModel.img.value)
            }
            context.startActivity(intent)

        }
    }
}