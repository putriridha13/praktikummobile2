package com.example.bismillahuas.ui.karnivora

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.example.bismillahuas.*

class karnivoraAdapter (
    private val context: Context,
    private val dataset: List<animals>
): RecyclerView.Adapter<karnivoraAdapter.karnivoraViewHolder> () {

    private val viewModel = animalsViewModel()
    class karnivoraViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val karnivoraImg: ImageView = view.findViewById((R.id.hewan_img))
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): karnivoraViewHolder {
        val layout = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.fragment_animals, parent, false)
        return karnivoraViewHolder(layout)
    }

    override fun getItemCount() = dataset.size

    override fun onBindViewHolder(holder: karnivoraViewHolder, position: Int) {
        val karnivoraData = dataset[position]
        holder.karnivoraImg.setImageResource(karnivoraData.imageResourceId)

        holder.itemView.setOnClickListener {
            viewModel.setAnimals(karnivoraData, context)

            val intent = Intent(context, animalsDetail::class.java). apply {
                putExtra("name", viewModel.name.value)
                putExtra("description", viewModel.desc.value)
                putExtra("image", viewModel.img.value)
            }
            context.startActivity(intent)
        }
    }
    }
