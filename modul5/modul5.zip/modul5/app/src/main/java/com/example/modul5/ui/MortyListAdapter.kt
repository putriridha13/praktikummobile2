package com.example.modul5.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.modul5.databinding.ListViewItemBinding
import com.example.modul5.network.MortyItem

class MortyListAdapter ( val clickListener: MortyListener) :
    ListAdapter<MortyItem, MortyListAdapter.MortyViewHolder>(DiffCallback) {

    class MortyViewHolder(
        var binding: ListViewItemBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(clickListener: MortyListener, morty: MortyItem) {
            binding.morty = morty
            binding.clickListener = clickListener
            binding.executePendingBindings()
        }
    }

    companion object DiffCallback: DiffUtil.ItemCallback<MortyItem>() {
        override fun areItemsTheSame(oldItem: MortyItem, newItem: MortyItem): Boolean {
            return oldItem.name == newItem.name
        }

        override fun areContentsTheSame(oldItem: MortyItem, newItem: MortyItem): Boolean {
            return oldItem.image == newItem.image
                    && oldItem.status == newItem.status
                    && oldItem.spesies == newItem.spesies
                    && oldItem.gender == newItem.gender
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MortyViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return MortyViewHolder(
            ListViewItemBinding.inflate(layoutInflater, parent, false)
        )
    }
    override fun onBindViewHolder(holder: MortyViewHolder, position: Int) {
        val morty = getItem(position)
        holder.bind(clickListener, morty)
    }
}

class MortyListener(val clickListener: (morty: MortyItem) -> Unit) {
    fun onClick(morty: MortyItem) = clickListener(morty)
}