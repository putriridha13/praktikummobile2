package com.example.bismillahuas

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class animalsViewModel: ViewModel() {
    private val _name = MutableLiveData<String> ()
    val name: LiveData<String>
    get() = _name

    private val _desc = MutableLiveData<String> ()
    val desc: LiveData<String>
    get() = _desc

    private val _img = MutableLiveData<Int> ()
    val img: LiveData<Int>
    get() = _img

    fun setAnimals(animals: animals, context: Context) {
        _name.value = context.resources.getString(animals.name)
        _desc.value = context.resources.getString(animals.desc)
        _img.value = animals.imageResourceId
    }

}