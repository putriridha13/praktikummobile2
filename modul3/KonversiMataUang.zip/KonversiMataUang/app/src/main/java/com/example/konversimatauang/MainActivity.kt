package com.example.konversimatauang

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import com.example.konversimatauang.databinding.ActivityMainBinding
import java.text.NumberFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnKonversi.setOnClickListener{ Konversi() }

        binding.inputEditText.setOnKeyListener{ view, keyCode, _ ->
            handleKeyEvent(
                view,
                keyCode
            )}
    }

    private fun  Konversi(){
        val Input = binding.inputEditText.text.toString()
        val uang = Input.toDoubleOrNull()

        if (uang == null) {
            binding.teksHasil.text = ""
            return
        }

        val pilihan = when (binding.pilihanMataUang.checkedRadioButtonId){
            R.id.EUR -> 15532
            R.id.USD -> 14367
            R.id.JPY -> 114
            else -> 3000
        }

        var Hasil =  uang * pilihan

        val indonesianLocale = Locale("in", "ID")
        val formatted =
            NumberFormat.getCurrencyInstance(indonesianLocale).format(Hasil)

        binding.teksHasil.text = getString(R.string.hasil, formatted)
    }


    private fun handleKeyEvent(view: View, keyCode: Int): Boolean {
        if (keyCode == KeyEvent.KEYCODE_ENTER) {

            val inputMethodManager =
                getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
            return true
        }
        return false
    }
}