package com.example.bismillahuas.ui.karnivora

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.bismillahuas.R
import com.example.bismillahuas.data
import com.example.bismillahuas.databinding.FragmentAnimalsItemBinding


class karnivoraFragment: Fragment(R.layout.fragment_animals_item) {
    private var _binding: FragmentAnimalsItemBinding? = null
    private val binding get() = _binding!!
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentAnimalsItemBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        recyclerView = binding.recyclerView
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = karnivoraAdapter(requireContext(), data().Karnivora())
    }

    override fun onDestroyView()  {
        super.onDestroyView()
        _binding = null
    }
}