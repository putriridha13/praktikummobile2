package com.example.modul5.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.modul5.network.MortyApi
import com.example.modul5.network.MortyItem
import kotlinx.coroutines.launch

enum class MortyApiStatus { LOADING, ERROR, DONE}

class MortyViewModel: ViewModel() {
    private val _status = MutableLiveData<MortyApiStatus>()
    val status: LiveData<MortyApiStatus> = _status

    private val _mortys = MutableLiveData<List<MortyItem>?> ()
    val mortys: MutableLiveData<List<MortyItem>?> = _mortys

    private val _morty = MutableLiveData<MortyItem>()
    val morty: LiveData<MortyItem> = _morty

    fun getMortyList() {
        viewModelScope.launch {
            _status.value = MortyApiStatus.LOADING
            try {
                _mortys.value = MortyApi.retrofitServiceApi.getMorty().results
                _status.value = MortyApiStatus.DONE
            } catch (e: Exception) {
                _mortys.value = listOf()
                _status.value = MortyApiStatus.ERROR
            }
        }
    }

    fun onMortyClicked(morty: MortyItem) {
        _morty.value = morty
    }
}