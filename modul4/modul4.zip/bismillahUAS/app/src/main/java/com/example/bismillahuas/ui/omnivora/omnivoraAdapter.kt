package com.example.bismillahuas.ui.omnivora

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.example.bismillahuas.R
import com.example.bismillahuas.animals
import com.example.bismillahuas.animalsDetail
import com.example.bismillahuas.animalsViewModel

class omnivoraAdapter (
    private val context: Context,
    private val dataset: List<animals>
    ): RecyclerView.Adapter<omnivoraAdapter.omnivoraViewHolder> (){

        private val viewModel = animalsViewModel()
    class omnivoraViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val omnivoraImg: ImageView = view.findViewById(R.id.hewan_img)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): omnivoraViewHolder {
        val layout = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.fragment_animals, parent, false)
        return omnivoraViewHolder(layout)
    }

    override fun getItemCount() = dataset.size

    override fun onBindViewHolder(holder: omnivoraViewHolder, position: Int) {
        val omnivoraData =  dataset[position]
        holder.omnivoraImg.setImageResource(omnivoraData.imageResourceId)

        holder.itemView.setOnClickListener {
            viewModel.setAnimals(omnivoraData, context)

            val intent = Intent(context, animalsDetail::class.java). apply {
                putExtra("name", viewModel.name.value)
                putExtra("description", viewModel.desc.value)
                putExtra("image", viewModel.img.value)
            }
            context.startActivity(intent)
        }
    }


}