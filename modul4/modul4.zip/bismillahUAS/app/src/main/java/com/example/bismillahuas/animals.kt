package com.example.bismillahuas

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class animals (
    @DrawableRes val imageResourceId: Int,
    @StringRes val name: Int,
    @StringRes val desc: Int
    )
