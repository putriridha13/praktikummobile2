package com.example.modul5.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.modul5.R
import com.example.modul5.databinding.FragmentMortyListBinding

class MortyListFragment: Fragment() {
    private val viewModel: MortyViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = FragmentMortyListBinding.inflate(inflater)
        viewModel.getMortyList()
        binding.lifecycleOwner = this
        binding.viewModel = viewModel
        binding.recyclerView.adapter = MortyListAdapter(MortyListener { morty ->
            viewModel.onMortyClicked(morty)
            findNavController()
                .navigate(R.id.action_mortyListFragment_to_mortyDetailFragment)
        })
        (activity as AppCompatActivity).supportActionBar?.title = "The Rick and Morty"

        return binding.root
    }
}