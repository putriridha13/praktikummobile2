package com.example.modul5.network


data class MortyProperty (
    val results : List<MortyItem>? = null,
)

data class MortyItem (
    val name: String? = null,
    val image : String? = null,
    val status : String? = null,
    val spesies: String? = null,
    val gender: String? = null
    )