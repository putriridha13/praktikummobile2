package com.example.bismillahuas

import androidx.lifecycle.ViewModel

class data : ViewModel() {
    fun herbivora(): List<animals> {
        return listOf(
            animals(
                R.drawable.h1, R.string.herbivora1, R.string.desh1),
            animals(
                R.drawable.h2, R.string.herbivora2, R.string.desh2),
            animals(
                R.drawable.h3, R.string.herbivora3, R.string.desh3),
            animals(
                R.drawable.h4, R.string.herbivora4, R.string.desh4),
            animals(
                R.drawable.h5, R.string.herbivora5, R.string.desh5),
            animals(
                R.drawable.h6, R.string.herbivora6, R.string.desh6)
        )
    }

    fun  Karnivora(): List<animals> {
        return listOf(
            animals(
                R.drawable.k1, R.string.karnivora1, R.string.desk1),
            animals(
                R.drawable.k2, R.string.karnivora2, R.string.desk2),
            animals(
                R.drawable.k3, R.string.karnivora3, R.string.desk3),
            animals(
                R.drawable.k4, R.string.karnivora4, R.string.desk4),
            animals(
                R.drawable.k5, R.string.karnivora5, R.string.desk5),
            animals(
                R.drawable.k6, R.string.karnivora6, R.string.desk6)
        )
    }

    fun  Omnivora(): List<animals> {
        return listOf(
            animals(
                R.drawable.o1, R.string.omnivora1, R.string.deso1),
            animals(
                R.drawable.o2, R.string.omnivora2, R.string.deso2),
            animals(
                R.drawable.o3, R.string.omnivora3, R.string.deso3),
            animals(
                R.drawable.o4, R.string.omnivora4, R.string.deso4),
            animals(
                R.drawable.o5, R.string.omnivora5, R.string.deso5),
            animals(
                R.drawable.o6, R.string.omnivora6, R.string.deso6)

        )
    }

}